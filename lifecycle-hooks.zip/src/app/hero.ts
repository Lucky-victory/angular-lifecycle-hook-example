export class Hero {
  constructor(public name: string) { }
}
